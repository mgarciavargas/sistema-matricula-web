<?php
define('DB_HOST', 'localhost');
define('DB_NAME', 'h257784_bdciclocero');
define('DB_USER', 'h257784_root');
define('DB_PASS', 'Peru2020');
